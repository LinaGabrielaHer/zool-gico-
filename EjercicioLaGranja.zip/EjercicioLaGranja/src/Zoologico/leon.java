/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Zoologico;

/**
 *
 * @author david
 */
public class leon extends AnimalCarnivoro {
    private float velocidad;
    public leon(int codigo, String nombre, float peso, int edad) {
        super(codigo, nombre, peso, edad);
    }

    
    public leon(int codigo, String nombre, float peso, int edad, float velocidad) {
        super(codigo, nombre, peso, edad);
        this.velocidad = velocidad;
    }

    public float getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(float velocidad) {
        this.velocidad = velocidad;
    }    
    
    @Override
    public String mostrarDatos() {
        return "leon{" + "codigo=" + getCodigo() + ", nombre=" + getNombre() + ", peso=" + getPeso() + "edad=" + getEdad() + "velocidad=" + velocidad + '}';
    }  
    
    
}
