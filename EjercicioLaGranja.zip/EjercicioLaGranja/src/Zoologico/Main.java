package Zoologico;

public class Main {
    public static void main(String[] args) {
        
        Animal misAnimales[] = new Animal[7];
        
        misAnimales[0] = new Jirafa(101, "jirafona", 200f, 3.5f, "amarillo");        
        misAnimales[1] = new Jirafa(102, "jirafita", 100f, 2.5f, "cafe");        
        misAnimales[2] = new Elefante(201, "dumbo", 800f, 2.5f, 100000f);        
        misAnimales[3] = new Puma(301, "puma", 100f, 8, 120f);
        misAnimales[4] = new Tortuga(401, "Juanito", 380f, 13, 5.6f);
        misAnimales[5] = new cabra(601,"cabra",380f, 13f,"rojo" );
        misAnimales[6] = new leon(302, "leon", 10f, 8, 10f);
        
        
        for(Animal i: misAnimales) {
           System.out.println(i.mostrarDatos());
           System.out.println("");
        }       
              
    }
}
